package ��ĩ;


 import java.util.Random;
 import java.util.Scanner;
 public class b {
     public static void main(String[] args) {
         int [][] arr=new int[10000][3];
         int [] temp01=new int [3];
         try (Scanner in = new Scanner(System.in)) {
			System.out.println("*******����******");
			 System.out.println("������������");
			 int m=in.nextInt();
			 int x=1,y=0,num1,num2,cmp;
			 boolean flag=false;
			 for (int i = 0; i < m; i++) {
			     flag=false;
			     Random r = new Random();
			     int temp;
			     num1 = r.nextInt(100)+1;
			     num2 = r.nextInt(100)+1;
			     cmp=r.nextInt(4);
			     temp01[0]=num1;
			     temp01[1]=num2;
			     temp01[2]=cmp;
			     for(int j=0;j<y;j++) {
			         if(arr[j]==temp01) {
			             flag=true;        
			             break;
			         }
			     }
			     if(flag)
			         continue;
			     else
			     {
			         arr[y][0]=num1;
			         arr[y][1]=num2;
			         arr[y][2]=cmp;
			         y++;
			         switch(cmp) {
			         case 0://��
			             System.out.print(""+x+"��"+num1+"+"+num2+"=   ");        
			             break;
			         case 1://��
			             if(num1<num2) {
			                 temp=num1;
			                 num1=num2;
			                 num2=temp;
			             }
			             System.out.print(""+x+"��"+num1+"-"+num2+"=    ");
			             break;
			         case 2://��
			             if(num1<num2) {
			                 temp=num1;
			                 num1=num2;
			                 num2=temp;
			             }
			             while(num1*num2>=100)
			                 num1--;
			             System.out.print(""+x+"��"+num1+"*"+num2+"=    ");
			             break;
			         case 3:
			             if(num1<num2) {
			                 temp=num1;
			                 num1=num2;
			                 num2=temp;
			             }
			             while(num1%num2!=0)
			                 num2--;
			             System.out.print(""+x+"��"+num1+"/"+num2+"=    ");
			             break;
			         }
			     }
			 }
		}
         
     }
 }