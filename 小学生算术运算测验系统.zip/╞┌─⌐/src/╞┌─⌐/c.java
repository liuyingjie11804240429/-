package 期末;

	import java.awt.BorderLayout;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.Comparator;
	import java.util.HashMap;
	import java.util.Iterator;
	import java.util.LinkedHashMap;
	import java.util.List;
	import java.util.Map;
	import java.util.Map.Entry;
	 
	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JPanel;
	import javax.swing.JTextArea;
	import javax.swing.JTextField;
	 
	
	public class c extends JFrame {
		
		private static final long serialVersionUID = 1L;
		JLabel lName,lScore;      
		JTextField tName,tScore;    
		JTextArea taShow;    
		JButton bSubmit;
		JPanel pan;
		Map<String,String> studentMap,resultMap;
		
		public void main(String[] args) {         
			new c();
		}
		
		public c() {              
			init();
			click();
		}
		//初始化方法
		public void init() {         
			lName=new JLabel("姓名");    
			lScore=new JLabel("成绩");
			tName=new JTextField(10);
			tScore=new JTextField(10);
			bSubmit=new JButton("确定");
			pan=new JPanel();
			taShow=new JTextArea();
			pan.add(lName);            
			pan.add(tName);
			pan.add(lScore);
			pan.add(tScore);
			pan.add(bSubmit);
			add(pan,BorderLayout.NORTH);     
			add(taShow, BorderLayout.CENTER);
			setTitle("统计学生姓名和分数");          
			setSize(400, 300);
			setVisible(true);
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			validate();
			studentMap=new HashMap<String,String>();                
		}
			
		private void click() {
			bSubmit.addActionListener(new ActionListener() {	   
				@Override
				public void actionPerformed(ActionEvent e) {
					save();
					showMap();
				}		
			});
		}
		
		private void save() {
			studentMap.put(tName.getText(),tScore.getText());
			resultMap = sortMapByValue(studentMap); 
			tName.setText("");         
			tScore.setText("");
		}
		
		public Map<String, String> sortMapByValue(Map<String, String> map) {
			if (map == null || map.isEmpty()) {
				return null;
			}
			Map<String, String> sortedMap = new LinkedHashMap<String, String>();
			List<Map.Entry<String, String>> entryList = new ArrayList<Map.Entry<String, String>>(map.entrySet());   //将元素存入List中，类型为entry
			Collections.sort(entryList, new MapValueComparator());
			Iterator<Map.Entry<String, String>> iter = entryList.iterator();
			Map.Entry<String, String> tmpEntry = null;
			while (iter.hasNext()) {
				tmpEntry = iter.next();
				sortedMap.put(tmpEntry.getKey(), tmpEntry.getValue());   //将List中的元素遍历出来存入map
			}
			return sortedMap;
		}
		//打印列表
		private void showMap() {
			taShow.setText("");
			for(Map.Entry<String,String> entry:resultMap.entrySet()) {	
				taShow.append("姓名："+entry.getKey()+"     成绩："+entry.getValue()+"\n");
			}		
		}	
	}
	//比较器类  
	class MapValueComparator implements Comparator<Map.Entry<String, String>> {
		public int compare(Entry<String, String> s1, Entry<String, String> s2) {
			return s1.getValue().compareTo(s2.getValue());
		}
	}

